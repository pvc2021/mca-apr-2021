package com.pradeep.productservice.controller;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.xray.spring.aop.XRayEnabled;
import com.pradeep.productservice.domain.Product;
import com.pradeep.productservice.service.IProductService;


@XRayEnabled
@RestController
@Scope("request")
@RequestMapping("/products")
public class ProductRestController {

	private static final Logger logger = Logger.getLogger(ProductRestController.class.getName());

	@Autowired
	private IProductService productService;

	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping
	public void addProduct(@RequestBody Product product) {
		productService.addProduct(product);
		logger.log(Level.INFO, "...Product is added successfully...");
		
	}

	@ResponseStatus(value = HttpStatus.OK)
	@PutMapping
	public void updateProduct(@RequestBody Product product) {
		productService.updateProduct(product);
		logger.log(Level.INFO, "...Product with id ["+product.getId()+"] is updated successfully...");
		
	}

	@ResponseStatus(value = HttpStatus.OK)

	@DeleteMapping(path = "/{productId}")
	public void deleteProduct(@PathVariable("productId") int productId) {

		productService.deleteProduct(productId);
		logger.log(Level.INFO, "...Product with id ["+productId+"] is deleted successfully");
		
	}

	@GetMapping("/{productId}")
	public Product findProduct(@PathVariable("productId") int productId) {
		logger.log(Level.INFO, "...Product with id ["+productId+"] is found successfully");
		
		return productService.findProductById(productId);
		
	}

	@GetMapping
	public List<Product> findAllProducts() {
		logger.log(Level.INFO, "...All Products retrieved successfully.....");

		return productService.findAllProducts();
	}

}
