package com.pradeep.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AvailabilityFilteringRule;
import com.netflix.loadbalancer.IPing;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.PingUrl;




public class RibbonClientConfiguration {

	public RibbonClientConfiguration() {
	System.out.println("CustomerServiceConfiguration created...");
	}
	
	@Autowired
    IClientConfig ribbonClientConfig;
    
	@Bean
    public IPing ribbonPing(IClientConfig config) {
		System.out.println("I Ping created...");
        return new PingUrl();
    }
    
	@Bean
    public IRule ribbonRule(IClientConfig config) {
		System.out.println("IRule created...");
        return new AvailabilityFilteringRule();
    }

	
   
	
	
	
}
