package com.pradeep.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class TestProductService {
	
	@Autowired
	RestTemplate restTemplate;
	
	private RestTemplate restTemplate1=new RestTemplate();
	
	
	@LoadBalanced
		@Bean
		RestTemplate restTemplate() {
			System.out.println("RestTemplate  created...");
			return new RestTemplate();
		}

	


	@HystrixCommand(fallbackMethod = "reliable")
	@GetMapping("/products")
     public String getAllProducts() {		
		String names = restTemplate.getForObject("http://pradeep-service/products", String.class);
		return names;
	}
	
	

	@HystrixCommand(fallbackMethod = "reliable")
	@GetMapping("/")
    public String getIndex() {		
		String names = restTemplate.getForObject("http://pradeep-service", String.class);
		return names;
	}
	
	
	@GetMapping("/users")
    public String getUsers() {		
		String users = restTemplate1.getForObject("https://jsonplaceholder.typicode.com/users", String.class);
		return users;
	}
	
	@HystrixCommand(fallbackMethod = "reliable")
	@GetMapping("/userdetails")
    public String getUserDetails() {	
	
		
		String userdetails = restTemplate1.getForObject("https://jsonplaceholder.typicode.com/usersdetails", String.class);
		return userdetails;
	}
	
		
	
	
	@GetMapping("/productdetails")
    public String getProductDetails() {	
		
		
		
		String userdetails = restTemplate1.getForObject("https://jsonplaceholder.typicode.com/productdetails", String.class);
		return userdetails;
	}
	
	
	public String reliable(){
		return "Dear User, Our Site is facing some issue\n Sorry for Inconvenience .Please try after some time";
	}


}
