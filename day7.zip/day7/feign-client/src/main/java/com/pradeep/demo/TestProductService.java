package com.pradeep.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestProductService {
	
	@Autowired
	private StoreFeignClient storeFeignClient;

	@GetMapping("/")
	public String getIndex() {
		return storeFeignClient.getIndex();

	}

	@GetMapping("/products")
	public String getProducts() {
		return storeFeignClient.getProducts();

	}
	
	

}
