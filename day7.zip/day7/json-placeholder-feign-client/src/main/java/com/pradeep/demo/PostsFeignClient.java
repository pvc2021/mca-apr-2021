package com.pradeep.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "post-service",url="https://jsonplaceholder.typicode.com/posts/")
public interface PostsFeignClient {
	
	
	@GetMapping
	public String getPosts();
	
	@GetMapping("/{postId}")
	public String getPostById(@PathVariable("postId") int postId);
	

}
