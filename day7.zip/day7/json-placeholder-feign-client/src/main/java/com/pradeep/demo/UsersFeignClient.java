package com.pradeep.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "user-service",url="https://jsonplaceholder.typicode.com/users/")
public interface UsersFeignClient {
	
	
	@GetMapping
	public String getUsers();
	
	@GetMapping("/{userId}")
	public String getUserById(@PathVariable("userId") int userId);
	

}
