package com.pradeep.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestJSONService {
	
	@Autowired
	private UsersFeignClient userClient;
	@Autowired
	private PostsFeignClient postClient;
	
	

	@GetMapping("/users")
	public String getUsers() {
		return userClient.getUsers();

	}

	@GetMapping("/users/{userId}")
	public String getUserByUserId(@PathVariable("userId") int userId) {
		return userClient.getUserById(userId);

	}
	
	
	@GetMapping("/posts")
	public String getPosts() {
		return postClient.getPosts();
		
	}

	@GetMapping("/posts/{postId}")
	public String getPostByPostId(@PathVariable("postId") int postId) {
		return postClient.getPostById(postId);

	}
	
	
}
