package com.pradeep.welcomeservice;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class GreetController {
	private static final Logger LOG = Logger.getLogger(GreetController.class.getName());
	
	@Autowired
	private RestTemplate restTemplate;
	
	   @RequestMapping("/greet")
	   public String index() {
	      LOG.log(Level.INFO, "Welome : Index API is calling");
	      return   restTemplate.getForObject("http://localhost:3333",String.class);
	   }
	   @RequestMapping("/")
	   public String hi() {
	      LOG.log(Level.INFO, "greet API is calling");
	      return "Greet Sleuth!";
	   }
}
