package com.pradeep.welcomeservice;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelccomeController {
	private static final Logger LOG = Logger.getLogger(WelccomeController.class.getName());
	   
	   @RequestMapping("/")
	   public String index() {
	      LOG.log(Level.INFO, "Index API is calling");
	      return "Welcome Sleuth!";
	   }
	   @RequestMapping("/hi")
	   public String hi() {
	      LOG.log(Level.INFO, "hi API is calling");
	      return "HI Sleuth!";
	   }
}
