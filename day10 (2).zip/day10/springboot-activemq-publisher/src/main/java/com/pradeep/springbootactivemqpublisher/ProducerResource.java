package com.pradeep.springbootactivemqpublisher;

import java.util.Date;

import javax.jms.DeliveryMode;
import javax.jms.Topic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/publish")
public class ProducerResource {

	@Autowired
	JmsTemplate jmsTemplate;

	@Autowired
	Topic topic;

	@GetMapping("/{message}")
	public String publish(@PathVariable("message") final String message) {

		jmsTemplate.setDeliveryMode(DeliveryMode.PERSISTENT);
		jmsTemplate.setDeliveryPersistent(true);
		jmsTemplate.convertAndSend(topic, message + " @ " + new Date());

		return "Published Message [" + message + "] Successfully";
	}
}
