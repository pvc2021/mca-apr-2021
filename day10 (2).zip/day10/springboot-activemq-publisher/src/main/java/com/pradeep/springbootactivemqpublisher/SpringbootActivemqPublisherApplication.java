package com.pradeep.springbootactivemqpublisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootActivemqPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootActivemqPublisherApplication.class, args);
	}

}
