package com.pradeep.filter;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.exception.ZuulException;

public class PostFilter extends ZuulFilter {

	private static final Logger logger = Logger.getLogger(PostFilter.class.getName());

	public PostFilter() {
		System.out.println("=====PostFilter created==============");
		}
	
	
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {

	
		logger.log(Level.INFO,
				".................................................................................................");

		logger.log(Level.INFO, "\n Inside Response Filter");

		logger.log(Level.INFO,
				".................................................................................................");

		return null;
	}

	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "post";
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

}
