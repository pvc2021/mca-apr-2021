package com.pradeep.filter;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class PreFilter extends ZuulFilter{
	
	
	private static final Logger logger = Logger.getLogger(PreFilter.class.getName());

	public PreFilter() {
		
		System.out.println("=====PreFilter created==============");
		}
	
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}
	
	
	@Override
	public Object run() throws ZuulException {
	
		HttpServletRequest request=RequestContext.getCurrentContext().getRequest();
		
		logger.log(Level.INFO, ".................................................................................................");
		
		
		logger.log(Level.INFO, "\n Request Method :"+request.getMethod()+"   Request URL:"+request.getRequestURI().toUpperCase());
		
		
		logger.log(Level.INFO, ".................................................................................................");
		

		
		
		
		return null;
	}
	
	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "pre";
	}
	
	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
