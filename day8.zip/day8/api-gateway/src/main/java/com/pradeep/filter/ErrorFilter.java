package com.pradeep.filter;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class ErrorFilter extends ZuulFilter {

	private static final Logger logger = Logger.getLogger(ErrorFilter.class.getName());

	public ErrorFilter() {
	
		System.out.println("=====ErrorFilter created==============");
		
	
	}
	
	
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {

	
		logger.log(Level.INFO,
				".................................................................................................");

		logger.log(Level.INFO, "\n Inside Error Filter");

		logger.log(Level.INFO,
				".................................................................................................");

		return null;
	}

	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "error";
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

}
