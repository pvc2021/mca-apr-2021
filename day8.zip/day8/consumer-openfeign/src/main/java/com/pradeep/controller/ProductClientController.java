package com.pradeep.controller;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.productservice.domain.Product;
import com.pradeep.proxy.ProductServiceProxy;

@RestController
@Scope("request")
public class ProductClientController {

	private static final Logger logger = Logger.getLogger(ProductClientController.class.getName());

	@Autowired
	private ProductServiceProxy productServiceProxy;

	@GetMapping("/get-products/{productId}")
	public Product getProductById(@PathVariable("productId")int productId) {

		logger.log(Level.INFO, "...Open Feign Calling ProductService getProductById API...");

		return productServiceProxy.getProductById(productId);
	}

	@GetMapping("/get-products")
	public List<Product> getAllProducts() {

		logger.log(Level.INFO, "...Open Feign Calling ProductService getAllProducts API...");

		return productServiceProxy.getAllProducts();
	}

}
