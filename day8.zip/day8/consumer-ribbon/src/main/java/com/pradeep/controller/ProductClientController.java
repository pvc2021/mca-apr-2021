package com.pradeep.controller;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.pradeep.productservice.domain.Product;

@RestController
public class ProductClientController {
	
	
	private static final Logger logger = Logger.getLogger(ProductClientController.class.getName());

	
	//Registry Aware HTTP Client
	@Autowired
	RestTemplate restTemplate;
		
	
	 @GetMapping("/get-products/{productId}")
     public Product getProductById(@PathVariable("productId")int productId) {		
		 logger.log(Level.INFO, "...Ribbon Client Calling ProductService getProductById API...");

		return restTemplate.getForObject("http://product-service/products/"+productId,Product.class);
	 }
	
	 @GetMapping("/get-products")
     public String getAllProducts() {		
		 logger.log(Level.INFO, "...Ribbon Client Calling ProductService getAllProducts API ...");

		return restTemplate.getForObject("http://product-service/products",Object.class).toString();
	 }
		
	

}
