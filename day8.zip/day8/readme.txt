step 1 : start admin-server                  : http://localhost:9090   :Monitoring
step 2 : start cloudserver-eureka            : http://localhost:8761   :Register & Discovery
step 3 : start cloudserver-config            : http://localhost:8888   :Externalized Config Management
step 4 : start zipkin-server                 : http://localhost:9411   :Distrubuted Tracing
step 5 : start product-service               : http://localhost:1111   :Product Service
step 5 : start product-service               : http://localhost:2222   :Product Service
step 5 : start product-service               : http://localhost:3333   :Product Service
step 6 : start api-gateway                   : http://localhost:8765   :Reverse Proxy
step 7 : start consumer-ribbon               : http://localhost:9997   :Client Side Load Balancing
step 8 : start consumer-openfeign            : http://localhost:9991   :Client Side Load Balancing
step 9 : start consumer-ribbon-hystrix       : http://localhost:9995   :Circuit Breaker Design Pattern
step 10: start consumer-openfeign-hystrix    : http://localhost:9994   :Circuit Breaker Design Pattern
