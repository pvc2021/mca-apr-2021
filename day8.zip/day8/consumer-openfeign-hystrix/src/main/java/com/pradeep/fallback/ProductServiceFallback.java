package com.pradeep.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.pradeep.productservice.domain.Product;
import com.pradeep.proxy.ProductServiceProxy;

@Service
public class ProductServiceFallback implements ProductServiceProxy {

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Product());
	}

	@Override
	public Product getProductById(int productId) {

		return new Product(166, "Camera", 1234.55);
	}

}
