### Creating Containers
#clear packages from STS

-mvn clean package

####Build Image

docker build -t pradeepch82/product-service-aws:1.0.0-RELEASE .


### Running Container
docker run --env RDS_URL=jdbc:h2:mem:testdb --env RDS_PASSWORD=password --env RDS_USERNAME=sa --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/product-service-aws:1.0.0-RELEASE

- docker network ls
- docker network inspect bridge

### Push the image to Docker hub

docker login
docker push pradeepch82/product-service-aws:1.0.0-RELEASE


Parameter Store
===================
/dev/product-service/RDS_URL
		jdbc:h2:mem:pradeepdb
     
/dev/product-service/RDS_DRIVER_CLASS
		org.h2.Driver

/dev/product-service/RDS_USERNAME
		sa

/dev/product-service/RDS_PASSWORD
		password

/dev/product-service/RDS_DIALECT
		org.hibernate.dialect.H2Dialect


Accessing Parameter stored in Parameter Store
=============================================
arn:aws:ssm:us-east-1:437975820344:parameter/dev/product-service/RDS_URL
arn:aws:ssm:us-east-1:437975820344:parameter/dev/product-service/RDS_USERNAME
arn:aws:ssm:us-east-1:437975820344:parameter/dev/product-service/RDS_PASSWORD
arn:aws:ssm:us-east-1:437975820344:parameter/dev/product-service/RDS_DIALECT
arn:aws:ssm:us-east-1:437975820344:parameter/dev/product-service/RDS_DRIVER_CLASS



#Consumer Service
#### Creating Containers
#clear package from STS

-mvn clean package

Build Image
============
docker build -t pradeepch82/aws-consumer-service:1.0.00-RELEASE .

#### Running Container
#### Basic

- docker images
- docker run --env PRODUCT_SERVICE_URI=http://172.17.0.3:8080 --publish 9995:9995 pradeepch82/aws-consumer-service:1.0.00-RELEASE
 



