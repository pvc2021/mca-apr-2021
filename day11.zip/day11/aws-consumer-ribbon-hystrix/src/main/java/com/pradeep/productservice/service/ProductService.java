package com.pradeep.productservice.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.pradeep.productservice.domain.Product;

@Service
@Scope("singleton")
public class ProductService {

	
	@Value("${PRODUCT_SERVICE_URI:http://localhost:8080}")
	private String productServiceHost;
	
	RestTemplate restTemplate=new RestTemplate();

	@HystrixCommand(fallbackMethod = "fallbackMethodByProductById")
	public Product getProductById(int productId) {
		return restTemplate.getForObject(productServiceHost+"api/product-microservice/products/" + productId, Product.class);
	}

	@HystrixCommand(fallbackMethod = "fallbackMethodgetAllProducts")
	public String getAllProducts() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return restTemplate.getForObject(productServiceHost+"api/product-microservice/products/", Object.class).toString();
	}

	
	
	public String fallbackMethodgetAllProducts() {
		return Arrays.asList(new Product(101, "ONIDA", 12000.88).toString()).toString();
	}

	
	
	public Product fallbackMethodByProductById(int productId) {
		return new Product(11, "TV", 12000.00);
					}

}
