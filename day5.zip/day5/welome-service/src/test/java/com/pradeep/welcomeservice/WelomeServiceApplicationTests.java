package com.pradeep.welcomeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelomeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
