package com.pradeep.cloudserverconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudserverConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
