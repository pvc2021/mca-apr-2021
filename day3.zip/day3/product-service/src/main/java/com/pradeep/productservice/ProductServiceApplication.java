package com.pradeep.productservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.pradeep.productservice.dao.ProductRepository;
import com.pradeep.productservice.domain.Product;



@EnableEurekaClient
@SpringBootApplication
public class ProductServiceApplication implements CommandLineRunner {

	
	@Autowired
	ProductRepository repository;
	
	
	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

	
	@Override
	public void run(String... args) throws Exception {
	System.out.println("=============Executing SQL Script====================");
		
	repository.save(new Product(null,"LG",11000.00));
	repository.save(new Product(null,"SONY",12000.00));
	repository.save(new Product(null,"SAMSUNG",13000.00));
	repository.save(new Product(null,"NOKIA",14000.00));
		
	}
}
