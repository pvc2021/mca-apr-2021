1.smart end points



product-service

/products      GET         
/products/1    GET         
/products/1    DELETE         
/products      PUT         
/products      POST         




Spring Boot starter dependencies
===================================
Spring Web
Spring Boot Actuator
Spring Boot Devtools
Spring Data JPA
H2 Database



ORM   (Object Relational Mapping)
===
-----------------------------------------------
                     product
-------------------------------------------------
productId    productName          productPrice
--------------------------------------------------
101            LG                 10000              Product product=new Product(101,"LG",10000);
102            SAMSUNG            20000              Product product=new Product(102,"SAMSUNG",20000);
   


class Product{
private int id;
private String name;
private double price;

}

Product product=new Product(101,"LG",10000);  ///Object Oriented data



                          @Component

@Controller             @Service            @Repository
@RestController


@RestController =@Controller + @ResponseBody





customer-service


customer
        customerId (auto gerated)
        name
        email 
        mobile         
        address
        

/customers     GET         
/customers/1   GET         
/customers/1   DELETE         
/customers    PUT         
/customers    POST    





public List<Employee> getEmployeeList(){



}

public ArrayList<Employee> getEmployeeList(){

}





