### Creating Containers
#clear packages from STS

-mvn clean package



Build Image

docker build -t pradeepch82/product-service-aws-xray:1.0.0-RELEASE .


### Running Container
Basic

docker run --env RDS_URL=jdbc:h2:mem:testdb --env RDS_PASSWORD=password --env RDS_USERNAME=sa --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/product-service-aws-xray:1.0.0-RELEASE


### Push the image to Docker hub
Basic

docker login
docker push @@REPO_NAME@@@/product-service-aws-xray:1.0.0-RELEASE

E.g docker push pradeepch82/product-service-aws-xray:1.0.0-RELEASE





/dev/product-service/RDS_URL
		jdbc:h2:mem:pradeepdb
     
/dev/product-service/RDS_DRIVER_CLASS
		org.h2.Driver

/dev/product-service/RDS_USERNAME
		sa

/dev/product-service/RDS_PASSWORD
		password

/dev/product-service/RDS_DIALECT
		org.hibernate.dialect.H2Dialect





